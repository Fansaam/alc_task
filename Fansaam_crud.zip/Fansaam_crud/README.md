## MY CRUD APPLICATION ##

**THIS CRUD APPLICATION** is a simple web application which performs CRUD functionalities using NodeJS, ExpressJS and MongoDB for Backend; while the Front end is developed using AngularJS


## Usage ##
1.Clone or download the "Fansaam_crud.zip" file and extract as "Fansaam_crud".
2.Start the CMD and Enter into this extracted folder path there.
2.Run **npm install** (if need be)
3.Open separate CMDs and Ensure to connect to the **MongoDB** and Start **Mongo Shell** using **mongod** and **mongo** respectively 
4.Go back and GitBash on "Fansaam_crud" again and Run **node app** to execute the application
5.Go to your web browser and type **Localhost:3000** to execute the API.
